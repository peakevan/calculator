import Vue from 'vue'
import Calculator from './Calculator.vue'

new Vue({
  el: '#calculator',
  render: h => h(Calculator)
})
